<?php include('../includes/header.php'); ?>
<?php include('../includes/db.php'); ?>

<div class="container">
    <h2>Add New Employee</h2>
    <form method="post" action="add_employee.php">
        <input type="text" name="name" placeholder="Employee Name" required>
        <input type="email" name="email" placeholder="Employee Email" required>
        <input type="text" name="phone" placeholder="Employee Phone">
        <input type="text" name="department" placeholder="Department">
        <button type="submit" name="submit">Add Employee</button>
    </form>
</div>

<?php
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $department = $_POST['department'];

    $sql = "INSERT INTO employees (name, email, phone, department) VALUES ('$name', '$email', '$phone', '$department')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New employee added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<?php include('../includes/footer.php'); ?>
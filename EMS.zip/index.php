<?php include('includes/header.php'); ?>
<div class="container">
    <h1>Welcome to Employee Management System</h1>
    <a href="pages/view_employees.php">View Employees</a> |
    <a href="pages/add_employee.php">Add New Employee</a>
</div>
<?php include('includes/footer.php'); ?>